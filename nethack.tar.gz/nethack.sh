# nethack

#GATEWAY=`route | grep default | awk '{ print $2 }'`
GATEWAY=`netstat -rn | grep ^0.0.0.0 | awk '{ print $2 }'`
GATEWAY_NAME=`route | grep default | awk '{ print $2 }'`
INTERFACE=`arp | grep "${GATEWAY_NAME} " | awk '{ print $5 }'`

echo ${GATEWAY}
echo ${INTERFACE}
/proj/nethack/nethack ${INTERFACE} ${GATEWAY}

